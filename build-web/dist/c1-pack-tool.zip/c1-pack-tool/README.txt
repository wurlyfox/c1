C1 WEB PACK CONVERTER - from your .bin to a ZIP with only what the game needs
===============================================================================

1. Install Python 3 (only the first time): https://www.python.org/downloads/
   On Windows tick "Add Python to PATH" while installing. macOS may offer to
   install it by itself the first time you run the converter.

2. Put your disc image (.bin or .iso of Crash Bandicoot, NTSC-U, SCUS-94900)
   in this folder, or in Downloads, Desktop or Documents.

3. Double-click:
   - Mac:      "Make pack (Mac).command"
               (if macOS blocks it: right-click -> Open -> Open)
   - Windows:  "Make pack (Windows).bat"
   - Linux / terminal:  python3 make_c1_pack.py "path/to/game.bin"
   The converter finds your image and writes c1-pack.zip next to it.

4. Open the c1 web page and pick that file with "Choose game ZIP".

The ZIP contains the level files of the game: it is for your own use only.
Do not share it.

-------------------------------------------------------------------------------

CONVERSOR DE C1 WEB - de tu .bin a un ZIP con solo lo que el juego necesita

1. Instala Python 3 (solo la primera vez): https://www.python.org/downloads/
   En Windows marca "Add Python to PATH" al instalar.

2. Pon tu imagen del disco (.bin o .iso de Crash Bandicoot, NTSC-U,
   SCUS-94900) en esta carpeta, o en Descargas, Escritorio o Documentos.

3. Doble clic en:
   - Mac:      "Make pack (Mac).command"
               (si macOS lo bloquea: clic derecho -> Abrir -> Abrir)
   - Windows:  "Make pack (Windows).bat"
   El conversor encuentra tu imagen y crea c1-pack.zip junto a ella.

4. Abre la pagina de c1 web y elige ese archivo con "Choose game ZIP".

El ZIP contiene los niveles del juego: es solo para tu uso personal.
No lo compartas.
